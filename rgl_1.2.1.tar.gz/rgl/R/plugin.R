##
## R source file
## This file is part of rgl
##
##

##
## quit R plugin
## 
##

rgl.quit <- function() {

  unloadNamespace("rgl")

}
